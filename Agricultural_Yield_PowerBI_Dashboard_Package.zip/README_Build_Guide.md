# Agricultural Yield Prediction Power BI Dashboard

## Data
Import `yield_prediction_powerbi_ready.csv` into Power BI as `Yield_Data`.

Rows: 1,625
Crop types: 30

## Model performance
R²: 0.9150
MAE: 0.8716
RMSE: 2.5665

## Page 1: Executive Overview
KPI cards:
- Total Yield
- Average Actual Yield
- Average Predicted Yield
- R² Score

Charts:
- Line chart: date_of_image on X-axis; Average Actual Yield and Average Predicted Yield as values
- Clustered column chart: crop_type vs Average Actual Yield
- Bar chart: field_id vs Average Actual Yield
- Slicers: crop_type, Year, field_id

## Page 2: Yield Drivers
Scatter charts:
- rainfall vs yield
- temperature vs yield
- ndvi vs yield
- soil_moisture vs yield
Use crop_type as legend where useful.

## Page 3: Regression Performance
KPI cards:
- R² Score
- MAE
- RMSE
- Average Error %

Scatter:
- X = yield
- Y = Predicted_Yield
- Add a constant/ideal reference line where X = Y if desired.

Bar charts:
- crop_type vs MAE
- field_id vs Average Absolute Error

## Page 4: Prediction Explorer
Slicers:
- crop_type
- field_id
- Year
- date_of_image

Cards:
- Actual Yield
- Predicted Yield
- Prediction Error
- Prediction Accuracy %

Table:
- field_id
- crop_type
- date_of_image
- yield
- Predicted_Yield
- Prediction_Error
- Prediction_Error_Pct

## Recommended relationships
This project can use a single fact table (`Yield_Data`) without relationships.

## Styling
Import `Agricultural_Yield_Theme.json` from View > Themes > Browse for themes.
